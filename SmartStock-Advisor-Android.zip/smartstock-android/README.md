# SMARTSTOCK-ADVISOR Android app

Android WebView wrapper for the SMARTSTOCK-ADVISOR mobile experience.

## Included
- Existing SmartStock Advisor website interface bundled in the app
- Help & Support section
- Support hours: Monday-Friday, 9:00 AM-4:00 PM; closed Saturday and Sunday
- Phone/WhatsApp: 7607692713
- Email: vineettiwari722@gmail.com
- 2-day (48-hour) demo information is included in the project build source

## Build
Open this folder in Android Studio and build the `app` module, or push it to GitHub to run the included Android GitHub Actions workflow.

The app is an informational interface. It does not execute trades or guarantee market returns.
