# SMARTSTOCK-ADVISOR Android app (v1.2)

Premium dark-theme Android WebView app for the SMARTSTOCK-ADVISOR website experience.

## Included in this build
- Premium responsive interface and branded Android launcher icon.
- NIFTY 50 / SENSEX ticker widget (requires internet and may be delayed by the data provider).
- Portfolio manager with manual current-price updates and device-local storage.
- Manual trade journal with BUY/SELL, entry, target, stop-loss, quantity, date, status, notes, risk estimate, delete, and CSV export.
- Android-native CSV save dialog for portfolio and trade-journal backups, plus browser download fallback.
- Market news links to NSE, BSE and Moneycontrol.
- Annual membership offer of ₹10,999, existing QR and WhatsApp/email support details.
- Android WebView handling for external web links, phone, email and WhatsApp links.

## Build validation and version
- App version: 1.2 (versionCode 3).
- Inline JavaScript syntax and Android XML resources were checked in the project workspace. A full APK build still requires Android SDK and Gradle.

## Important: features that are not live yet
This project does **not** contain a production backend. Secure paid-member login, demo-account expiry, admin-issued member credentials, payment gateway verification, screenshot review, cross-device portfolio sync, and private paid-member trade delivery are not implemented. A browser-only password or localStorage lock would not securely protect paid content, so it has intentionally not been presented as real authentication. These features need a backend/database and a payment provider integration before accepting paid memberships as automatically activated.

Portfolio and trade-journal entries are saved only on the current device/browser. Export the trade journal CSV for backup. The market ticker and external news require internet. This app does not execute trades or provide guaranteed investment returns.

## Build APK with GitHub Actions (free GitHub Actions minutes may be available)
1. Create a GitHub repository and upload the **contents of this project folder** to the repository root (the `.github` folder must be at the repository root).
2. Open the repository's **Actions** tab.
3. Select **Build SMARTSTOCK-ADVISOR APK** and choose **Run workflow** (or push to `main` / `master`).
4. When the workflow finishes, open the run and download the `SMARTSTOCK-ADVISOR-debug-apk` artifact. Extract it to get `app-debug.apk`.

## Local Android Studio build
Open this project folder in Android Studio, allow Gradle sync, install Android SDK Platform 35 if prompted, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Output: `app/build/outputs/apk/debug/app-debug.apk`.
