package com.smartstock.advisor;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int CREATE_CSV_FILE = 4107;
    private static final String HOME = "file:///android_asset/index.html";
    private WebView webView;
    private String pendingCsv = "";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (android.os.Build.VERSION.SDK_INT >= 26) settings.setSafeBrowsingEnabled(true);
        WebView.setWebContentsDebuggingEnabled(false);

        // This bridge is used only by the bundled, local app page to save CSV backups.
        webView.addJavascriptInterface(new CsvBridge(), "AndroidDownloads");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return openExternal(request.getUrl());
            }
            @Override @SuppressWarnings("deprecation") public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return openExternal(Uri.parse(url));
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        if (savedInstanceState != null && webView.restoreState(savedInstanceState) != null) {
            // Restored WebView state; local portfolio and trade records remain in WebView storage.
        } else {
            webView.loadUrl(HOME);
        }
    }

    private boolean openExternal(Uri uri) {
        String scheme = uri.getScheme();
        if (scheme == null || "file".equals(scheme) || "about".equals(scheme)) return false;
        if ("http".equals(scheme) || "https".equals(scheme) || "mailto".equals(scheme)
                || "tel".equals(scheme) || "sms".equals(scheme)) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
            catch (Exception e) { Toast.makeText(this, "Is link ko kholne ke liye app available nahi hai.", Toast.LENGTH_SHORT).show(); }
            return true;
        }
        return true;
    }

    private class CsvBridge {
        @JavascriptInterface public void saveCsv(String filename, String csv) {
            if (filename == null || csv == null || csv.length() > 2_000_000) return;
            String safeName = filename.replaceAll("[^A-Za-z0-9._-]", "_");
            if (!safeName.toLowerCase().endsWith(".csv")) safeName += ".csv";
            final String name = safeName;
            final String content = csv;
            runOnUiThread(() -> {
                pendingCsv = content;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("text/csv");
                intent.putExtra(Intent.EXTRA_TITLE, name);
                try { startActivityForResult(intent, CREATE_CSV_FILE); }
                catch (Exception e) {
                    pendingCsv = "";
                    Toast.makeText(MainActivity.this, "CSV save option open nahi hua.", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != CREATE_CSV_FILE) return;
        if (resultCode == RESULT_OK && data != null && data.getData() != null) {
            try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                if (out == null) throw new IllegalStateException("No output stream");
                out.write(pendingCsv.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                Toast.makeText(this, "CSV file save ho gayi.", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "CSV save nahi ho saki. Dobara try karein.", Toast.LENGTH_LONG).show();
            }
        }
        pendingCsv = "";
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.stopLoading(); webView.removeJavascriptInterface("AndroidDownloads"); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
